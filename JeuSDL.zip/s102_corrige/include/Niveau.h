#ifndef NIVEAU_H
#define NIVEAU_H

#include "Objet.h"
#include "Dictionnaire.h"

#include <vector>

using namespace std;

class Niveau
{
  vector<Objet> _objets;
  int _nbPieces;
  bool _ennemisActifs; //Question 2.1

public:

  Niveau (Image image, const string& nomDuFichier, const Dictionnaire& dictionnaire);

  void dessiner() const;

  // Retourne `true` si la case n'est pas occupee par un objet "solide"
  bool caseEstLibre(int x, int y) const;

  void testerBonusEtPrendre(int x, int y);

  // S'il y a un objet de propriete "propriete" à la case (x,y), cette
  // fonction retourne son indice dans le vecteur _objets. Sinon, elle
  // retourne -1.
  int indiceObjet(int x, int y, const string& propriete) const;

  bool gagne() const;
  bool ennemisActifs() const ; //Question 2.1
  void testerSpecial(int x,int y);//Question 2.2
  void testerCoffreEtInteragir(int x,int y,Dictionnaire & Dico);//Question 3.2
};

#endif // NIVEAU_H
