CREATE TABLE Client (
    idClient INT PRIMARY KEY,
    nom VARCHAR(50) NOT NULL,
    prenom VARCHAR(50) NOT NULL,
    date_de_naissance DATE,
    adresse_electronique VARCHAR(100) UNIQUE
);

CREATE TABLE Reservation (
    numreservation INT PRIMARY KEY,
    idClient INT NOT NULL,
    ville_depart VARCHAR(100),
    ville_arrivee VARCHAR(100),
    date_reservation DATE,
    FOREIGN KEY (idClient) REFERENCES Client(idClient) ON DELETE CASCADE
);

CREATE TABLE Voyage (
    idvoyage INT PRIMARY KEY,
    nom_voyage VARCHAR(100),
    nbplaces INT NOT NULL,
    description TEXT
);

CREATE TABLE Trajet (
    idtrajet INT PRIMARY KEY,
    idvoyage INT NOT NULL,
    heure_de_depart DATETIME,
    heure_d_arrivée DATETIME,
    prix_final DECIMAL(10, 2),
    FOREIGN KEY (idvoyage) REFERENCES Voyage(idvoyage) ON DELETE CASCADE
);
