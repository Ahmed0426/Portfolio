-- Sélectionne tous les clients triés par leur nom
SELECT * FROM Client ORDER BY nom;

-- Affiche les réservations ainsi que le nom et le prénom des clients associés,
-- filtré par un nom de client ou un numéro de réservation spécifique
SELECT Reservation.*, Client.nom, Client.prenom
FROM Reservation
JOIN Client ON Reservation.idClient = Client.idClient
WHERE Client.nom = 'NOM_CLIENT' OR Reservation.numreservation = 'NUM_RESERVATION';

-- Sélectionne les clients nés après le 1er janvier 2000
SELECT * FROM Client
WHERE date_de_naissance > '2000-01-01';

-- Affiche les clients ayant plus de 5 réservations
SELECT idClient, nom, prenom, COUNT(numreservation) AS nombre_reservations
FROM Reservation
JOIN Client ON Reservation.idClient = Client.idClient
GROUP BY idClient
HAVING COUNT(numreservation) > 5;

-- Sélectionne tous les voyages qui sont complets (aucune place restante)
SELECT Voyage.*
FROM Voyage
WHERE nbplaces = 0;

-- Compte le nombre de réservations pour chaque ville de départ
SELECT ville_depart, COUNT(numreservation) AS tickets_vendus
FROM Reservation
GROUP BY ville_depart;

-- Calcule le total des achats pour un client donné
SELECT Client.nom, Client.prenom, SUM(Trajet.prix_final) AS total_achat
FROM Reservation
JOIN Client ON Reservation.idClient = Client.idClient
JOIN Trajet ON Reservation.numreservation = Trajet.idtrajet
WHERE Client.nom = 'NOM_CLIENT';

-- Calcule le total des achats pour un client donné pour les trajets commencés le 1er janvier 2025
SELECT Client.nom, Client.prenom, SUM(Trajet.prix_final) AS total_achat
FROM Reservation
JOIN Client ON Reservation.idClient = Client.idClient
JOIN Trajet ON Reservation.numreservation = Trajet.idtrajet
WHERE Client.nom = 'NOM_CLIENT' AND Trajet.heure_de_depart LIKE '2025-01-01%';

-- Affiche les 5 trajets les plus vendus (ceux ayant le plus de réservations)
SELECT Trajet.idtrajet, COUNT(Reservation.numreservation) AS ventes
FROM Reservation
JOIN Trajet ON Reservation.numreservation = Trajet.idtrajet
GROUP BY Trajet.idtrajet
ORDER BY ventes DESC
LIMIT 5;

-- Affiche les 5 trajets les moins vendus (ceux ayant le moins de réservations)
SELECT Trajet.idtrajet, COUNT(Reservation.numreservation) AS ventes
FROM Reservation
JOIN Trajet ON Reservation.numreservation = Trajet.idtrajet
GROUP BY Trajet.idtrajet
ORDER BY ventes ASC
LIMIT 5;

-- Affiche tous les détails d'un trajet en fonction de son numéro
SELECT * FROM Trajet WHERE idtrajet = 'NUM_TRAJET';

-- Sélectionne les trajets où l'heure d'arrivée est postérieure à l'heure de départ (valide)
SELECT * FROM Trajet
WHERE heure_d_arrivée > heure_de_depart;

-- Sélectionne les trajets dont l'heure de départ est le 1er janvier 2025 ou après
SELECT * FROM Trajet
WHERE heure_de_depart >= '2025-01-01';

-- Calcule le revenu total de tous les trajets
SELECT SUM(Trajet.prix_final) AS revenu_total
FROM Trajet;

-- Calcule le revenu total des trajets ayant lieu en décembre 2024
SELECT SUM(Trajet.prix_final) AS revenu_total
FROM Trajet
WHERE heure_de_depart >= '2024-12-01' AND heure_de_depart < '2025-01-01';

-- Sélectionne un client en fonction de son adresse e-mail
SELECT * FROM Client
WHERE adresse_electronique = 'EMAIL_CLIENT';

-- Sélectionne tous les trajets ayant lieu avant le 1er janvier 2025
SELECT * FROM Trajet
WHERE heure_de_depart < '2025-01-01';

-- Compte le nombre total de clients
SELECT COUNT(*) AS total_clients
FROM Client;

-- Compte le nombre de tickets vendus pour les réservations en janvier 2025
SELECT COUNT(*) AS tickets_vendus
FROM Reservation
WHERE ville_depart LIKE '2025-01-%';

-- Compte le nombre total de trajets enregistrés
SELECT COUNT(*) AS total_trains
FROM Trajet;
