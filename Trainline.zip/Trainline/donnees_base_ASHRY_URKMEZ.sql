INSERT INTO Voyageur (idVoyageur, nom, prenom, date_de_naissance, numreservation) VALUES
('V001', 'Jean', 'Dupont', '1985-03-12', 'R001'),
('V002', 'Marie', 'Dupont', '1987-08-22', 'R001'),
('V003', 'Claire', 'Martin', '1990-07-23', 'R002'),
('V004', 'Luc', 'Bernard', '1982-11-30', 'R003'),
('V005', 'Alice', 'Bernard', '1990-03-10', 'R003');

INSERT INTO Voyage (idcompagnie, id_moyen_de_transport, nbplaces, correspondance, moyen_de_transport, Prix_de_base, temps_de_trajet) VALUES
('CP001', 'V001', 100, 'Oui', 'Bus', 150.0, '01:30'),
('CP002', 'V002', 50, 'Non', 'Train', 50.0, '03:00'),
('CP003', 'V003', 30, 'Non', 'Train', 100.0, '05:00');

INSERT INTO Trajet (idtrajet, gare_de_depart, gare_de_destination, heure_de_depart, heure_d_arrivee, prix_final, idcompagnie, id_moyen_de_transport) VALUES
('T001', 'Paris', 'Lyon', '10:00', '13:00', 55.0, 'CP002', 'V002'),
('T002', 'Nice', 'Marseille', '12:00', '15:30', 160.0, 'CP001', 'V001'),
('T003', 'Toulon', 'Ajaccio', '08:00', '13:00', 120.0, 'CP003', 'V003');

INSERT INTO Reservation (numreservation, preference_siege, possession_animal, ville_depart, destination, idcompagnie, id_moyen_de_transport, idClient) VALUES 
('R001', 'Fenêtre', 'Non', 'Paris', 'Lyon', 'CP002', 'V002', 'C001'),
('R002', 'Couloir', 'Oui', 'Nice', 'Marseille', 'CP001', 'V001', 'C002'),
('R003', 'Fenêtre', 'Non', 'Toulon', 'Ajaccio', 'CP003', 'V003', 'C003');

INSERT INTO Paiement (numreservation, idpaiement, numero_de_carte, date_d_expiration, nom_de_carte, CVV) VALUES 
('R001', 'P001', '1234567812345678', '12/25', 'Jean Dupont', 123),
('R002', 'P002', '2345678923456789', '06/26', 'Claire Martin', 456),
('R003', 'P003', '3456789034567890', '03/27', 'Luc Bernard', 789);

INSERT INTO Compagnie (idcompagnie, nom_compagnie) VALUES 
('CP001', 'Compagnie de Train Express'),
('CP002', 'Compagnie Eurostar'),
('CP003', 'Compagnie Ouibus');

INSERT INTO Client (idClient, nom, prenom, adresse_electronique, mot_de_passe, num_carte_de_reduction) VALUES 
('C001', 'Dupont', 'Jean', 'jean.dupont@email.com', 'Motdepasse123', 123456789012),
('C002', 'Martin', 'Claire', 'claire.martin@email.com', 'Motdepasse456', 987654321098),
('C003', 'Bernard', 'Luc', 'luc.bernard@email.com', 'Motdepasse789', 456789123456);
